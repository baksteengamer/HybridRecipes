package xyz.hybridmc.hybridrecipes;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.ShapelessRecipe;

public final class CustomRecipes {

    public static void register() {
        ShapelessRecipe recipe0 = new ShapelessRecipe(new NamespacedKey(Main.getInstance(), "SuperString"));
    }

}
