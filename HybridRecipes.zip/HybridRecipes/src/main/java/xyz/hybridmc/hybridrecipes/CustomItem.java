package xyz.hybridmc.hybridrecipes;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Item;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;

public final class CustomItem {

    public static void register() {
        ItemStack superString = new ItemStack(Material.STRING, 1);
        ItemMeta superStringMeta = superString.getItemMeta();
        superStringMeta.setDisplayName("§bSuper String");
        superString.setItemMeta(superStringMeta);

        ShapelessRecipe recipe0 = new ShapelessRecipe(new NamespacedKey(Main.getInstance(), "SuperString"), superString);
        recipe0.addIngredient(9, Material.STRING);
        Bukkit.addRecipe(recipe0);

        ItemStack meltingString = new ItemStack(Material.STRING, 1);
        ItemMeta meltingStringMeta = meltingString.getItemMeta();
        meltingStringMeta.setDisplayName("§cMelting String");
        meltingStringMeta.addEnchant(Enchantment.DURABILITY, 3, true);
        meltingStringMeta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        meltingString.setItemMeta(meltingStringMeta);

        FurnaceRecipe recipe1 = new FurnaceRecipe(new NamespacedKey(Main.getInstance(), "MeltingString"),
                meltingString, new RecipeChoice.ExactChoice(superString), 30, 120);
        Bukkit.addRecipe(recipe1);

        ItemStack meltingRod = new ItemStack(Material.FISHING_ROD, 1);
        ItemMeta meltingRodMeta = meltingRod.getItemMeta();
        meltingRodMeta.setDisplayName("§cMelting String");
        meltingRodMeta.addEnchant(Enchantment.DURABILITY, 3, true);
        meltingRodMeta.addEnchant(Enchantment.LURE, 5, true);
        meltingRodMeta.addEnchant(Enchantment.LUCK, 3, true);
        meltingRod.setItemMeta(meltingRodMeta);

        ShapedRecipe recipe2 = new ShapedRecipe(new NamespacedKey(Main.getInstance(), "Melting Rod"), meltingRod);
        recipe2.shape(
                " D ",
                "DBD",
                " D ");

        recipe2.setIngredient('D', meltingString);
        recipe2.setIngredient('B', new ItemStack(Material.FISHING_ROD, 1);
        Bukkit.addRecipe(recipe2);
    }
}
